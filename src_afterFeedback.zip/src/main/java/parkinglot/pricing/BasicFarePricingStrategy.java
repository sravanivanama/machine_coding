package parkinglot.pricing;

import parkinglot.constants.PricingFare;
import parkinglot.enums.VehicleType;
import parkinglot.model.ParkingTicket;

import java.util.logging.Logger;

public class BasicFarePricingStrategy implements PricingStrategy{

    private static final Logger LOGGER = Logger.getLogger("BasicFarePricingStrategy");
    @Override
    public double calculateFare(ParkingTicket parkingTicket){
        double fare =  PricingFare.BASIC_FARE;
        LOGGER.info("Total fare for Parking Ticket: "+parkingTicket+" is: "+fare);
        return fare;
    }
}
