package parkinglot.model;

import parkinglot.enums.VehicleType;

public abstract class ParkingSpot {
    /*
     We have parking spots for different types of vehicles -> It currently support Car, Bike, Truck
     */
    VehicleType vehicleType;
    int spotId;
    boolean isEmpty;

    public  ParkingSpot(int spotId){
        this.spotId = spotId;
        isEmpty = true;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public boolean isEmpty(){
        return isEmpty;
    }

    public void occupySpot(){
        isEmpty = false;
    }

    public void freeSpot(){
        isEmpty = true;
    }


    public int getSpotId(){
        return spotId;
    }

    @Override
    public String toString(){
        return "Parking Spot: spotId: "+ spotId+", vehicleType: "+vehicleType.toString();
    }
}


