# FeedBack

1. I missed adding DAO/Repository classes i.e. maintaining active central repository to get things back
2. Missed clarifying requirements:

    a. Assumed that slots per floor would be fixed, GET THIS CLARIFIED FROM INTERVIEWER
    
    b. Also ask for number of CAR, BIKE, TRUCK SLOTS -> if no. of slots are dynamic, how to distribte vehicles per type
        
        i. Static  -> Equal distibution
        ii. Custom -> Taking from input itself that car:6, bike: 8, truck:6
        iii. Dynamic -> Slots would be generic, based on size we can allocate...lte's say if bike sare full and car is empty, then bike can take car space

3. Also all the models where needed did not have ids. -> Like ParkingTicket did not have ticketId
4. Missed edge cases like, 
   
        i. Duplicate vehicle registration number in parking lot
        ii. InvalidTicket given while unparking
5. Pricing Strategy -> This is just hardcoded in code, needs to be pluggable and should have some strategy.

         i. Basic fare for all the vehicles -> like 20rs/hr
        ii. (SLAB - BASED)Fare based on vehicle type and duration -> Take it as input or either store it in DB

6. ParkingSpot -> to have cleaner APIs like freeSpot(), occupySpot() instead of setAvailable etc...
7. toString overrides missing in few classes and also instead of logs -> these rounds expect System.out
8. blockSpot -> always assumes there is a spot ->potential NPE
9. concurrency issues
