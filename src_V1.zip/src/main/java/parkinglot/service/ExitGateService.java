package parkinglot.service;

import parkinglot.enums.VehicleType;
import parkinglot.exception.InvalidVehicleType;
import parkinglot.model.ParkingSpot;
import parkinglot.model.ParkingTicket;

import java.util.logging.Logger;

import static parkinglot.constants.NumericConstants.HOURS;
import static parkinglot.constants.PricingFare.*;

public class ExitGateService {

    private static final Logger LOGGER = Logger.getLogger("ExitGateService");
    public double unparkVehicle(ParkingTicket ticket) throws InvalidVehicleType {
        LOGGER.info("Start of unparking vehicle for ticket: "+ticket);
        ParkingSpot spot = ticket.getSpot();
        spot.setAvailable();
        return calculateFare(ticket);
    }
    public double calculateFare(ParkingTicket parkingTicket) throws InvalidVehicleType {
        VehicleType type = parkingTicket.getVehicle().getVehicleType();
        double basicFare = getBasicFareByVehicleType(type);
        long endTime = System.currentTimeMillis();
        long durationInHrs = (endTime - parkingTicket.getStartTime())/HOURS;
        double fare = 0;
        if(durationInHrs < 1){
            fare = basicFare;
        } else {
            fare = basicFare + (durationInHrs - 1) * INCREMENT_FEE;
        }
        LOGGER.info("Total fare for Parking Ticket: "+parkingTicket+" is: "+fare);
        return fare;

    }

    public double getBasicFareByVehicleType(VehicleType type) throws InvalidVehicleType {
        switch (type){
            case CAR:  return CAR_FEE;
            case BIKE: return BIKE_FEE;
            case TRUCK: return TRUCK_FEE;
            default:
                throw new InvalidVehicleType("Invalid VehicleType received to calculate fare: "+type);
        }
    }
}
