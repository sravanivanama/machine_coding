package parkinglot;

import parkinglot.enums.VehicleType;
import parkinglot.exception.InvalidVehicleType;
import parkinglot.exception.NoParkingSpotAvailable;
import parkinglot.model.ParkingLot;
import parkinglot.model.ParkingTicket;
import parkinglot.service.ExitGateService;
import parkinglot.service.ParkingLotService;

public class ParkingLotDriver {
    public static void main(String[] args) throws InvalidVehicleType, NoParkingSpotAvailable {
        ParkingLot parkingLot = new ParkingLot(2);
        ParkingLotService parkingLotService = new ParkingLotService(parkingLot);
        parkingLotService.getAvailableParkingSpots(VehicleType.CAR);
        parkingLotService.getAvailableParkingSpots(VehicleType.BIKE);
        ParkingTicket ticket = parkingLotService.issueTicket("KA-01-HH-1234", "CAR");
        ParkingTicket ticket1 = parkingLotService.issueTicket("KA-01-HH-9999","BIKE");
        parkingLotService.getAvailableParkingSpots(VehicleType.CAR);
        ExitGateService exitGateService = new ExitGateService();
        exitGateService.unparkVehicle(ticket);
        exitGateService.unparkVehicle(ticket1);
        parkingLotService.getAvailableParkingSpots(VehicleType.CAR);
        parkingLotService.getAvailableParkingSpots(VehicleType.BIKE);

    }
}
