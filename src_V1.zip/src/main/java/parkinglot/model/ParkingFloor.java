package parkinglot.model;

import parkinglot.constants.NumericConstants;
import parkinglot.enums.VehicleType;

import java.util.*;
import java.util.stream.Collectors;

import static parkinglot.constants.NumericConstants.*;

public class ParkingFloor {
    /*
     A Parking Floor has multiple Parking Slots
     */
    int floorId;
    int spots;

    ParkingSpot[] parkingSpots;

    public ParkingFloor(int floorId){
        this.floorId = floorId;
        spots = NumericConstants.TOTAL_SLOTS;
        parkingSpots = new ParkingSpot[spots];
        initCarSpots(CAR_SLOTS, 0);
        initBikeSpots(BIKE_SLOTS, CAR_SLOTS);
        initTruckSpots(TRUCK_SLOTS, CAR_SLOTS+BIKE_SLOTS);
    }
    public int getFloorId(){
        return floorId;
    }
    public ParkingSpot[] getParkingSpots(){
        return parkingSpots;
    }

    public void initCarSpots(int carSlots, int i){
        while(i< carSlots){
            CarParkingSpot spot = new CarParkingSpot(i);
            parkingSpots[i] = spot;
            i++;
        }
    }


    public void initBikeSpots(int bikeSlots, int i){
        int initial = i;
        while(i< initial+bikeSlots){
            BikeParkingSpot spot = new BikeParkingSpot(i);
            parkingSpots[i] = spot;
            i++;
        }
    }

    public void initTruckSpots(int truckSlots, int i){
        int initial = i;
        while(i< initial+truckSlots){
            TruckParkingSpot spot = new TruckParkingSpot(i);
            parkingSpots[i] = spot;
            i++;
        }
    }

    public List<ParkingSpot> getAvailableParkingSpots(VehicleType vehicleType) {
        if(parkingSpots != null) {
            return Arrays.stream(parkingSpots).filter(spot -> spot.isEmpty() && spot.vehicleType.equals(vehicleType)).collect(Collectors.toList());
        } else {
            return new ArrayList<>();
        }
    }

}
