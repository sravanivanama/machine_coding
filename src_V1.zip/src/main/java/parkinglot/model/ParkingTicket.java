package parkinglot.model;

public class ParkingTicket {

    Vehicle vehicle;

    public long getStartTime() {
        return startTime;
    }

    long startTime;

    ParkingSpot spot;

    public ParkingTicket(Vehicle vehicle, long startTime, ParkingSpot spot){
        this.spot = spot;
        this.vehicle = vehicle;
        this.startTime = startTime;
    }

    public ParkingSpot getSpot(){
        return spot;
    }

    public Vehicle getVehicle(){
        return vehicle;
    }

    @Override
    public String toString(){
        return "Ticket: "+ vehicle.toString()+ ", "+spot.toString()+"Time: "+startTime;
    }
}
