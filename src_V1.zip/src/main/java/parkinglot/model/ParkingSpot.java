package parkinglot.model;

import parkinglot.enums.VehicleType;

public abstract class ParkingSpot {
    /*
     We have parking spots for different types of vehicles -> It currently support Car, Bike, Truck
     */
    VehicleType vehicleType;
    int spotId;
    boolean isEmpty;

    public  ParkingSpot(int spotId){
        this.spotId = spotId;
        isEmpty = true;
    }

    public VehicleType getVehicleType() {
        return vehicleType;
    }

    public boolean isEmpty(){
        return isEmpty;
    }

    public void setBooked(){
        isEmpty = false;
    }

    public void setAvailable(){
        isEmpty = true;
    }


    public int getSpotId(){
        return spotId;
    }
}


