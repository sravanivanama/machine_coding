package parkinglot.constants;

public class PricingFare {
    public static final double CAR_FEE = 50;
    public static final double BIKE_FEE = 20;
    public static final double TRUCK_FEE = 70;

    public static final double INCREMENT_FEE = 10;

}
