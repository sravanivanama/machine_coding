package parkinglot.constants;

import parkinglot.enums.VehicleType;

import java.util.HashMap;
import java.util.Map;

import static parkinglot.enums.VehicleType.*;

public class NumericConstants {
    public static final int BIKE_SLOTS = 100;

    public static final int CAR_SLOTS = 70;

    public static final int TRUCK_SLOTS = 50;

    public static final int TOTAL_SLOTS = BIKE_SLOTS + CAR_SLOTS + TRUCK_SLOTS;

    public static final long HOURS = 60 *60 * 1000;
}
